# views/view_menu.py
class MenuView:
    def tampilkan_menu(self, daftar):
        print("Daftar Menu:")
        print("-" * 34)
        print("{:<5} {:<20} {:>5}".format("ID |", "Nama Menu |", "Harga |"))
        print("-" * 34)
        if not daftar:
            print("Daftar Menu Kosong.\n")

        for item in daftar:
            print("{:<5} {:<20} {:>5}".format(item.id_menu, item.nama, item.harga))
        print("-" * 34)

    def tambah_menu(self):
        nama = input("Masukkan Nama Menu: ")
        while True:
            try:
                harga = int(input("Masukkan Harga Menu: "))
                break
            except ValueError:
                print("Harga harus berupa angka. Silakan coba lagi.")
        return nama, harga

