# models/model_menu.py
class MenuItem:
    def __init__(self, id_menu, nama, harga):
        self.id_menu = id_menu
        self.nama = nama
        self.harga = harga

class MenuModel:
    def __init__(self):
        self.daftar_menu = []
        self.next_id = 1

    def tambah_menu(self, nama, harga):
        menu_item = MenuItem(self.next_id, nama, harga)
        self.daftar_menu.append(menu_item)
        self.next_id += 1
        return menu_item

    def get_daftar_menu(self):
        return self.daftar_menu