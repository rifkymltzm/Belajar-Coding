# controllers/controller_menu.py
from models.model_menu import MenuModel
from views.view_menu import MenuView


class MenuController:
    def __init__(self):
        print("Controller Menu diinisialisasi")
        self.model = MenuModel()
        self.view = MenuView()

    def tampilkan_menu(self):
        daftar = self.model.get_daftar_menu()
        self.view.tampilkan_menu(daftar)

        if not daftar:
            pilihan = input("Apakah Anda ingin menambahkan menu baru? (y/n): ")
            if pilihan.lower() == 'y':
                self.tambah_menu() 

    def tambah_menu(self):
        nama, harga = self.view.tambah_menu()
        menu_item = self.model.tambah_menu(nama, harga)
        print(f"Menu '{menu_item.nama}' dengan harga {menu_item.harga} telah ditambahkan dengan ID {menu_item.id_menu}.")